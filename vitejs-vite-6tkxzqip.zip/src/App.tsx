import React, { useMemo, useState } from "react";
import LEMMAS from "./lemmi.json"; // elenco ~100+ sostantivi

/** Tipi base */
type Decl = 1 | 2 | 3 | 4 | 5;
type NumTag = "sg" | "pl";
const CASES = ["Nominativo", "Genitivo", "Dativo", "Accusativo", "Ablativo", "Vocativo"] as const;

interface Noun {
  nom: string;            // nominativo sing.
  gen: string;            // genitivo sing.
  gender: "m" | "f" | "n";
  decl: Decl;
  meaning?: string;
}
interface Forms { [k: string]: string; }

/** Utilità */
function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}
function byDecl(d: Decl, data: Noun[]) {
  return data.filter(l => l.decl === d);
}
function normalize(s: string) {
  return s
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ")
    .replace(/[āēīōūȳ]/g, (m) => ({ "ā":"a","ē":"e","ī":"i","ō":"o","ū":"u","ȳ":"y" } as any)[m] || m);
}

/** Ricava il tema dal genitivo */
function stemFromGen(gen: string, decl: Decl) {
  if (decl === 1) return gen.replace(/ae$/, "");
  if (decl === 2) return gen.replace(/i$/, "");
  if (decl === 3) return gen.replace(/is$/, "");
  if (decl === 4) return gen.replace(/us$/, "");
  return gen.replace(/ei$/, ""); // V
}

/** Costruzione delle forme (regole base per I–V) */
function buildForms(n: Noun): Record<NumTag, Forms> {
  const stem = stemFromGen(n.gen, n.decl);
  const sg: Forms = {};
  const pl: Forms = {};

  switch (n.decl) {
    case 1: {
      sg.Nominativo = n.nom;  sg.Genitivo = n.gen;  sg.Dativo = stem + "ae";
      sg.Accusativo = stem + "am"; sg.Ablativo = stem + "a"; sg.Vocativo = stem + "a";
      pl.Nominativo = stem + "ae"; pl.Genitivo = stem + "arum"; pl.Dativo = stem + "is";
      pl.Accusativo = stem + "as"; pl.Ablativo = stem + "is"; pl.Vocativo = stem + "ae";
      break;
    }
    case 2: {
      const neut = n.gender === "n";
      const vocSg =
        /ius$/.test(n.nom) ? n.nom.replace(/ius$/, "i")
        : /us$/.test(n.nom) ? n.nom.replace(/us$/, "e")
        : n.nom; // vir/nomi in -er invariati
      sg.Nominativo = n.nom; sg.Genitivo = n.gen; sg.Dativo = stem + "o";
      sg.Accusativo = stem + "um"; sg.Ablativo = stem + "o"; sg.Vocativo = vocSg;
      pl.Nominativo = neut ? stem + "a" : stem + "i";
      pl.Genitivo = stem + "orum"; pl.Dativo = stem + "is";
      pl.Accusativo = neut ? stem + "a" : stem + "os";
      pl.Ablativo = stem + "is"; pl.Vocativo = neut ? stem + "a" : stem + "i";
      break;
    }
    case 3: {
      const neut = n.gender === "n";
      sg.Nominativo = n.nom; sg.Genitivo = n.gen; sg.Dativo = stem + "i";
      sg.Accusativo = neut ? n.nom : stem + "em";
      sg.Ablativo = stem + "e";
      sg.Vocativo = n.nom;
      pl.Nominativo = neut ? stem + "a" : stem + "es";
      pl.Genitivo = stem + "um";
      pl.Dativo = stem + "ibus";
      pl.Accusativo = neut ? stem + "a" : stem + "es";
      pl.Ablativo = stem + "ibus";
      pl.Vocativo = pl.Nominativo;
      break;
    }
    case 4: {
      const neut = n.gender === "n";
      sg.Nominativo = n.nom; sg.Genitivo = n.gen; sg.Dativo = stem + "ui";
      sg.Accusativo = neut ? n.nom : stem + "um";
      sg.Ablativo = stem + "u"; sg.Vocativo = n.nom;
      pl.Nominativo = neut ? stem + "ua" : stem + "us";
      pl.Genitivo = stem + "uum"; pl.Dativo = stem + "ibus";
      pl.Accusativo = neut ? stem + "ua" : stem + "us";
      pl.Ablativo = stem + "ibus"; pl.Vocativo = pl.Nominativo;
      break;
    }
    case 5: {
      sg.Nominativo = n.nom; sg.Genitivo = n.gen; sg.Dativo = stem + "ei";
      sg.Accusativo = stem + "em"; sg.Ablativo = stem + "e"; sg.Vocativo = n.nom;
      pl.Nominativo = stem + "es"; pl.Genitivo = stem + "erum"; pl.Dativo = stem + "ebus";
      pl.Accusativo = stem + "es"; pl.Ablativo = stem + "ebus"; pl.Vocativo = stem + "es";
      break;
    }
  }
  return { sg, pl };
}

/** Stato iniziale per i campi */
const emptyInputs = () => ({
  sg: Object.fromEntries(CASES.map(c => [c, ""])) as Forms,
  pl: Object.fromEntries(CASES.map(c => [c, ""])) as Forms
});

export default function App() {
  const data = LEMMAS as Noun[];

  const [mode, setMode] = useState<"byDecl" | "any">("byDecl");
  const [decl, setDecl] = useState<Decl>(1);
  const [current, setCurrent] = useState<Noun | null>(null);
  const [answers, setAnswers] = useState(emptyInputs());
  const [checked, setChecked] = useState(false);
  const [score, setScore] = useState({ correct: 0, total: 0 });

  const solution = useMemo(() => (current ? buildForms(current) : null), [current]);

  function newWord() {
    const pool = mode === "byDecl" ? byDecl(decl, data) : data;
    const noun = pick(pool);
    setCurrent(noun);
    setAnswers(emptyInputs());
    setChecked(false);
  }

  function check() {
    if (!solution) return;
    let c = 0, t = 0;
    (["sg", "pl"] as NumTag[]).forEach(num => {
      CASES.forEach(k => {
        t += 1;
        const user = normalize((answers as any)[num][k]);
        const corr = normalize((solution as any)[num][k]);
        if (user === corr) c += 1;
      });
    });
    setChecked(true);
    setScore(prev => ({ correct: prev.correct + c, total: prev.total + t }));
  }

  function fillCorrect() {
    if (!solution) return;
    setAnswers({ sg: { ...solution.sg }, pl: { ...solution.pl } } as any);
    setChecked(true);
  }

  function resetScore() {
    setScore({ correct: 0, total: 0 });
  }

  return (
    <div style={{ fontFamily: "system-ui, Arial, sans-serif", padding: 16, maxWidth: 900, margin: "0 auto" }}>
      <h1 style={{ margin: "0 0 12px" }}>Quiz Declinazioni Latine</h1>

      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center", marginBottom: 12 }}>
        <label>
          Modalità:{" "}
          <select value={mode} onChange={e => setMode(e.target.value as any)}>
            <option value="byDecl">Scegli declinazione</option>
            <option value="any">Qualsiasi declinazione</option>
          </select>
        </label>

        {mode === "byDecl" && (
          <label>
            {" "}Declinazione:{" "}
            <select value={decl} onChange={e => setDecl(Number(e.target.value) as Decl)}>
              <option value={1}>I</option>
              <option value={2}>II</option>
              <option value={3}>III</option>
              <option value={4}>IV</option>
              <option value={5}>V</option>
            </select>
          </label>
        )}

        <button onClick={newWord}>Nuovo sostantivo</button>
        <button onClick={fillCorrect} disabled={!current}>Mostra soluzione</button>
        <button onClick={resetScore}>Azzera punteggio</button>
      </div>

      <div style={{ marginBottom: 8, fontSize: 14, color: "#444" }}>
        Punteggio: <strong>{score.correct}</strong> / {score.total}
        {score.total > 0 && <> — {(100 * score.correct / score.total).toFixed(0)}%</>}
      </div>

      {!current && <div style={{ fontSize: 14, color: "#666" }}>Premi “Nuovo sostantivo”.</div>}

      {current && solution && (
        <div style={{ border: "1px solid #ddd", borderRadius: 8, padding: 12 }}>
          <div style={{ marginBottom: 8 }}>
            <strong>Parola:</strong> {current.nom}{" "}
            <span style={{ color: "#666" }}>
              (gen. {current.gen}, decl. {current.decl}, {current.gender})
            </span>
            {current.meaning && <span style={{ color: "#777" }}> — {current.meaning}</span>}
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            {(["sg", "pl"] as NumTag[]).map(numTag => (
              <div key={numTag}>
                <div style={{ fontSize: 12, color: "#666", textTransform: "uppercase", marginBottom: 6 }}>
                  {numTag === "sg" ? "Singolare" : "Plurale"}
                </div>
                {CASES.map(cName => {
                  const val = (answers as any)[numTag][cName];
                  const corr = (solution as any)[numTag][cName];
                  const ok = checked && normalize(val) === normalize(corr);
                  const bad = checked && !ok;
                  return (
                    <div key={cName} style={{ marginBottom: 8 }}>
                      <label style={{ display: "block", fontSize: 13, marginBottom: 4 }}>{cName}</label>
                      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                        <input
                          value={val}
                          onChange={e =>
                            setAnswers(prev => ({
                              ...prev,
                              [numTag]: { ...(prev as any)[numTag], [cName]: e.target.value }
                            }))
                          }
                          placeholder="scrivi la forma"
                          style={{
                            flex: 1,
                            padding: "6px 8px",
                            borderRadius: 6,
                            border: "1px solid",
                            borderColor: ok ? "#22c55e" : bad ? "#ef4444" : "#ccc"
                          }}
                        />
                        {checked && (ok ? "✅" : "❌")}
                      </div>
                      {checked && bad && (
                        <div style={{ fontSize: 12, color: "#666" }}>
                          Soluzione: <code>{corr}</code>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>

          <div style={{ marginTop: 12 }}>
            <button onClick={check}>Finito — correggi</button>
          </div>
        </div>
      )}
    </div>
  );
}
